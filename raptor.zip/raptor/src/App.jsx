// App.jsx
import { Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider, useAuth } from './context/AuthContext'
import AuthPage   from './components/auth/AuthPage'
import AppLayout  from './components/layout/AppLayout'

function ProtectedRoute({ children }) {
  const { session, loading } = useAuth()
  if (loading) return <LoadingScreen />
  return session ? children : <Navigate to="/auth" replace />
}

function LoadingScreen() {
  return (
    <div className="h-full flex items-center justify-center bg-raptor-void">
      <div className="text-center animate-fade-in">
        <div className="raptor-logo text-5xl text-raptor-amber tracking-widest mb-3">RAPTOR</div>
        <div className="flex gap-1.5 justify-center">
          {[0,1,2].map(i => (
            <div key={i} className="w-1.5 h-1.5 rounded-full bg-raptor-amber animate-bounce"
              style={{ animationDelay: `${i * 0.15}s` }} />
          ))}
        </div>
      </div>
    </div>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/auth" element={<AuthPage />} />
        <Route path="/*" element={
          <ProtectedRoute>
            <AppLayout />
          </ProtectedRoute>
        } />
      </Routes>
    </AuthProvider>
  )
}
