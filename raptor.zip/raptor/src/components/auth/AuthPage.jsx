// components/auth/AuthPage.jsx
// The login / sign-up page with Raptor branding.

import { useState } from 'react'
import { Navigate } from 'react-router-dom'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../context/AuthContext'
import { Eye, EyeOff, Zap } from 'lucide-react'

export default function AuthPage() {
  const { session } = useAuth()
  const [mode, setMode]         = useState('login')   // 'login' | 'signup'
  const [username, setUsername] = useState('')
  const [email, setEmail]       = useState('')
  const [password, setPassword] = useState('')
  const [showPw, setShowPw]     = useState(false)
  const [error, setError]       = useState('')
  const [loading, setLoading]   = useState(false)
  const [success, setSuccess]   = useState('')

  if (session) return <Navigate to="/" replace />

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setSuccess('')
    setLoading(true)

    if (mode === 'signup') {
      if (username.length < 2) { setError('Username must be at least 2 characters.'); setLoading(false); return }
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: { data: { username } },
      })
      if (error) setError(error.message)
      else setSuccess('Account created! Check your email to confirm, then log in.')
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email, password })
      if (error) setError(error.message)
    }
    setLoading(false)
  }

  return (
    <div className="min-h-screen bg-raptor-void flex items-center justify-center p-4 relative overflow-hidden">
      {/* Ambient background effects */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-raptor-amber/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 left-1/4 w-64 h-64 bg-raptor-amber/3 rounded-full blur-3xl" />
        {/* Grid lines */}
        <div className="absolute inset-0" style={{
          backgroundImage: 'linear-gradient(rgba(245,158,11,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(245,158,11,0.04) 1px, transparent 1px)',
          backgroundSize: '48px 48px'
        }} />
      </div>

      <div className="relative w-full max-w-md animate-fade-in">
        {/* Logo */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 mb-3">
            <div className="w-8 h-8 bg-raptor-amber rounded flex items-center justify-center">
              <Zap size={18} className="text-raptor-void" fill="currentColor" />
            </div>
            <span className="raptor-logo text-4xl text-raptor-amber tracking-widest">RAPTOR</span>
          </div>
          <p className="text-raptor-sub text-sm font-body">
            {mode === 'login' ? 'Welcome back. Log in to continue.' : 'Create your account.'}
          </p>
        </div>

        {/* Card */}
        <div className="bg-raptor-dark border border-raptor-border rounded-lg p-8 shadow-2xl">
          {/* Toggle */}
          <div className="flex bg-raptor-pit rounded-md p-1 mb-7">
            {['login','signup'].map(m => (
              <button
                key={m}
                onClick={() => { setMode(m); setError(''); setSuccess('') }}
                className={`flex-1 py-1.5 rounded text-sm font-medium transition-all duration-150 ${
                  mode === m
                    ? 'bg-raptor-amber text-raptor-void'
                    : 'text-raptor-sub hover:text-raptor-text'
                }`}
              >
                {m === 'login' ? 'Log In' : 'Sign Up'}
              </button>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'signup' && (
              <Field label="Username">
                <input
                  type="text"
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  placeholder="raptor_user"
                  required
                  className="raptor-input"
                  autoComplete="off"
                />
              </Field>
            )}

            <Field label="Email">
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="you@example.com"
                required
                className="raptor-input"
              />
            </Field>

            <Field label="Password">
              <div className="relative">
                <input
                  type={showPw ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  minLength={6}
                  className="raptor-input pr-10"
                />
                <button type="button" onClick={() => setShowPw(!showPw)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-raptor-faint hover:text-raptor-sub transition-colors">
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </Field>

            {error   && <p className="text-raptor-dnd text-sm animate-fade-in">{error}</p>}
            {success && <p className="text-raptor-online text-sm animate-fade-in">{success}</p>}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-raptor-amber hover:bg-raptor-gold text-raptor-void font-semibold py-2.5 rounded-md transition-colors disabled:opacity-50 mt-2"
            >
              {loading ? 'Please wait…' : mode === 'login' ? 'Log In' : 'Create Account'}
            </button>
          </form>
        </div>

        <p className="text-center text-raptor-faint text-xs mt-6">
          By continuing you agree to our Terms of Service and Privacy Policy.
        </p>
      </div>

      {/* Inline style for input */}
      <style>{`
        .raptor-input {
          width: 100%;
          background: #111820;
          border: 1px solid #2E3D50;
          color: #E2EAF3;
          border-radius: 6px;
          padding: 9px 12px;
          font-size: 14px;
          font-family: 'DM Sans', sans-serif;
          outline: none;
          transition: border-color 0.15s;
        }
        .raptor-input:focus { border-color: #F59E0B; }
        .raptor-input::placeholder { color: #4D6278; }
      `}</style>
    </div>
  )
}

function Field({ label, children }) {
  return (
    <div>
      <label className="block text-raptor-sub text-xs font-semibold uppercase tracking-wider mb-1.5">
        {label}
      </label>
      {children}
    </div>
  )
}
