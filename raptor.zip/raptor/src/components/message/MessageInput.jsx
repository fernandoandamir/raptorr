// components/message/MessageInput.jsx
// Rich chat input with typing indicator emission and emoji toggle.

import { useState, useRef, useCallback } from 'react'
import { supabase } from '../../lib/supabase'
import { Send, Smile } from 'lucide-react'
import EmojiPicker from './EmojiPicker'

const TYPING_THROTTLE = 2000   // ms between typing DB updates
const TYPING_STOP    = 3000   // ms after last keystroke to clear typing

export default function MessageInput({ placeholder, onSend, channelId, userId }) {
  const [content, setContent]     = useState('')
  const [showEmoji, setShowEmoji] = useState(false)
  const typingTimer  = useRef(null)
  const lastTyped    = useRef(0)
  const textareaRef  = useRef(null)

  // ── Typing indicator ──────────────────────────────────────────
  const emitTyping = useCallback(async () => {
    if (!channelId || !userId) return
    const now = Date.now()
    if (now - lastTyped.current > TYPING_THROTTLE) {
      lastTyped.current = now
      await supabase.from('typing').upsert(
        { channel_id: channelId, user_id: userId, updated_at: new Date().toISOString() },
        { onConflict: 'channel_id,user_id' }
      )
    }
    clearTimeout(typingTimer.current)
    typingTimer.current = setTimeout(async () => {
      await supabase.from('typing').delete()
        .eq('channel_id', channelId).eq('user_id', userId)
    }, TYPING_STOP)
  }, [channelId, userId])

  const clearTyping = useCallback(async () => {
    clearTimeout(typingTimer.current)
    if (channelId && userId) {
      await supabase.from('typing').delete()
        .eq('channel_id', channelId).eq('user_id', userId)
    }
  }, [channelId, userId])

  // ── Send ───────────────────────────────────────────────────────
  const handleSend = async () => {
    const trimmed = content.trim()
    if (!trimmed) return
    setContent('')
    await clearTyping()
    await onSend(trimmed)
    textareaRef.current?.focus()
  }

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const handleChange = (e) => {
    setContent(e.target.value)
    if (e.target.value) emitTyping()
  }

  const insertEmoji = (emoji) => {
    setContent(prev => prev + emoji)
    setShowEmoji(false)
    textareaRef.current?.focus()
  }

  return (
    <div className="relative flex items-end gap-2 bg-raptor-surface border border-raptor-border rounded-lg px-3 py-2.5 focus-within:border-raptor-border transition-colors">
      {/* Textarea */}
      <textarea
        ref={textareaRef}
        value={content}
        onChange={handleChange}
        onKeyDown={handleKeyDown}
        placeholder={placeholder}
        rows={1}
        style={{ resize: 'none', maxHeight: '160px' }}
        className="flex-1 bg-transparent text-raptor-text text-sm outline-none placeholder:text-raptor-faint font-body leading-relaxed overflow-y-auto"
        onInput={e => {
          // Auto-grow
          e.target.style.height = 'auto'
          e.target.style.height = Math.min(e.target.scrollHeight, 160) + 'px'
        }}
      />

      {/* Emoji button */}
      <div className="relative flex-shrink-0">
        <button
          onClick={() => setShowEmoji(!showEmoji)}
          className="text-raptor-faint hover:text-raptor-sub transition-colors p-0.5"
          title="Emoji"
        >
          <Smile size={18} />
        </button>
        {showEmoji && (
          <div className="absolute right-0 bottom-full mb-2 z-50">
            <EmojiPicker onSelect={insertEmoji} onClose={() => setShowEmoji(false)} />
          </div>
        )}
      </div>

      {/* Send button */}
      <button
        onClick={handleSend}
        disabled={!content.trim()}
        className="flex-shrink-0 bg-raptor-amber disabled:opacity-30 text-raptor-void p-1.5 rounded-md transition-colors hover:bg-raptor-gold disabled:cursor-not-allowed"
        title="Send (Enter)"
      >
        <Send size={14} />
      </button>
    </div>
  )
}
