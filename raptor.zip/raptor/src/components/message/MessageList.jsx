// components/message/MessageList.jsx
// Renders the scrollable list of messages, grouping consecutive messages
// from the same author to mimic Discord's "compact" style.

import { useRef, useEffect } from 'react'
import MessageRow from './MessageRow'

export default function MessageList({ messages, currentUser, channelId }) {
  const listRef = useRef(null)

  // Auto-scroll on initial load
  useEffect(() => {
    if (listRef.current) {
      listRef.current.scrollTop = listRef.current.scrollHeight
    }
  }, [])

  if (messages.length === 0) {
    return (
      <div className="flex-1 flex items-end px-4 pb-2">
        <div className="text-raptor-faint text-sm">
          No messages yet. Be the first to say something!
        </div>
      </div>
    )
  }

  // Group messages: a message is "grouped" (no avatar/name) if the previous
  // message is from the same author within 5 minutes.
  const enriched = messages.map((msg, i) => {
    const prev = messages[i - 1]
    const isGrouped =
      prev &&
      prev.author_id === msg.author_id &&
      new Date(msg.created_at) - new Date(prev.created_at) < 5 * 60 * 1000

    return { ...msg, isGrouped }
  })

  return (
    <div
      ref={listRef}
      className="flex-1 overflow-y-auto px-4 py-2 space-y-0.5 min-h-0"
    >
      {enriched.map(msg => (
        <MessageRow
          key={msg.id}
          message={msg}
          isGrouped={msg.isGrouped}
          isOwn={msg.author_id === currentUser?.id}
          currentUser={currentUser}
          channelId={channelId}
        />
      ))}
    </div>
  )
}
