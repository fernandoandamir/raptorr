// components/message/EmojiPicker.jsx
// A compact emoji picker with common emojis.

import { useEffect, useRef } from 'react'

const EMOJIS = [
  '👍','👎','❤️','🔥','😂','😮','😢','😡',
  '🎉','✅','🚀','👀','💯','🙏','⚡','💀',
  '🤔','😎','🥳','👋','💪','🫡','🤝','😅',
]

export default function EmojiPicker({ onSelect, onClose }) {
  const ref = useRef(null)

  // Close on outside click
  useEffect(() => {
    const handler = (e) => {
      if (ref.current && !ref.current.contains(e.target)) onClose()
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [onClose])

  return (
    <div
      ref={ref}
      className="bg-raptor-surface border border-raptor-border rounded-lg p-2 shadow-2xl animate-fade-in"
    >
      <div className="grid grid-cols-8 gap-1">
        {EMOJIS.map(emoji => (
          <button
            key={emoji}
            onClick={() => onSelect(emoji)}
            className="w-7 h-7 flex items-center justify-center text-lg rounded hover:bg-raptor-raised transition-colors"
            title={emoji}
          >
            {emoji}
          </button>
        ))}
      </div>
    </div>
  )
}
