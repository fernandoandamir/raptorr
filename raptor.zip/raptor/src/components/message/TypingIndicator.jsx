// components/message/TypingIndicator.jsx
// Shows "Alice is typing…" using realtime subscriptions on the typing table.

import { useState, useEffect } from 'react'
import { supabase } from '../../lib/supabase'

export default function TypingIndicator({ channelId, currentUserId }) {
  const [typers, setTypers] = useState([])  // array of { user_id, username }

  useEffect(() => {
    if (!channelId) return

    // Poll/subscribe to typing table for this channel
    const ch = supabase
      .channel(`typing:${channelId}`)
      .on('postgres_changes', {
        event: '*', schema: 'public', table: 'typing',
        filter: `channel_id=eq.${channelId}`,
      }, async () => {
        // Re-fetch who is typing (excluding self)
        const { data } = await supabase
          .from('typing')
          .select('user_id, users(username)')
          .eq('channel_id', channelId)
          .neq('user_id', currentUserId)
          // Only show if updated within last 5 seconds
          .gte('updated_at', new Date(Date.now() - 5000).toISOString())
        setTypers(data?.map(t => ({ user_id: t.user_id, username: t.users?.username })) ?? [])
      })
      .subscribe()

    return () => supabase.removeChannel(ch)
  }, [channelId, currentUserId])

  if (typers.length === 0) return <div className="h-5 flex-shrink-0" />

  const label =
    typers.length === 1
      ? `${typers[0].username} is typing`
      : typers.length === 2
        ? `${typers[0].username} and ${typers[1].username} are typing`
        : `${typers.length} people are typing`

  return (
    <div className="flex items-center gap-2 px-4 h-5 flex-shrink-0">
      <div className="flex gap-0.5 items-center">
        {[0,1,2].map(i => (
          <span key={i} className="typing-dot w-1 h-1 rounded-full bg-raptor-sub block" />
        ))}
      </div>
      <span className="text-raptor-sub text-xs">{label}…</span>
    </div>
  )
}
