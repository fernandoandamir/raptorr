// components/message/MessageRow.jsx
// A single chat message row with hover actions (edit, delete, react).

import { useState, useRef } from 'react'
import { format, isToday, isYesterday } from 'date-fns'
import { supabase } from '../../lib/supabase'
import Avatar from '../ui/Avatar'
import EmojiPicker from './EmojiPicker'
import { Pencil, Trash2, Smile, Check, X } from 'lucide-react'

function formatTime(ts) {
  const d = new Date(ts)
  if (isToday(d))     return `Today at ${format(d, 'h:mm a')}`
  if (isYesterday(d)) return `Yesterday at ${format(d, 'h:mm a')}`
  return format(d, 'MMM d, yyyy h:mm a')
}

// Group reactions by emoji
function groupReactions(reactions = []) {
  return reactions.reduce((acc, r) => {
    if (!acc[r.emoji]) acc[r.emoji] = []
    acc[r.emoji].push(r.user_id)
    return acc
  }, {})
}

export default function MessageRow({ message, isGrouped, isOwn, currentUser, channelId }) {
  const [editing,     setEditing]     = useState(false)
  const [editContent, setEditContent] = useState(message.content)
  const [showEmoji,   setShowEmoji]   = useState(false)
  const emojiRef = useRef(null)

  const reactionGroups = groupReactions(message.reactions)

  // ── Edit message ─────────────────────────────────────────────
  const handleEdit = async () => {
    if (!editContent.trim() || editContent === message.content) {
      setEditing(false); return
    }
    await supabase.from('messages')
      .update({ content: editContent.trim(), edited_at: new Date().toISOString() })
      .eq('id', message.id)
    setEditing(false)
  }

  const handleEditKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleEdit() }
    if (e.key === 'Escape') { setEditing(false); setEditContent(message.content) }
  }

  // ── Delete message ────────────────────────────────────────────
  const handleDelete = async () => {
    await supabase.from('messages').delete().eq('id', message.id)
  }

  // ── React ──────────────────────────────────────────────────────
  const handleReact = async (emoji) => {
    setShowEmoji(false)
    const existing = message.reactions?.find(
      r => r.emoji === emoji && r.user_id === currentUser?.id
    )
    if (existing) {
      await supabase.from('reactions').delete().eq('id', existing.id)
    } else {
      await supabase.from('reactions').insert({
        message_id: message.id,
        user_id:    currentUser?.id,
        emoji,
      })
    }
  }

  const author = message.author

  return (
    <div className={`message-row group relative flex gap-3 px-2 py-0.5 rounded-md hover:bg-raptor-dark/50 transition-colors ${isGrouped ? 'mt-0' : 'mt-3'}`}>
      {/* Avatar / timestamp stub */}
      <div className="w-10 flex-shrink-0 flex items-start justify-center">
        {isGrouped ? (
          <span className="text-[10px] text-raptor-faint opacity-0 group-hover:opacity-100 transition-opacity mt-1 leading-none select-none">
            {format(new Date(message.created_at), 'h:mm')}
          </span>
        ) : (
          <Avatar user={author} size={38} />
        )}
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0">
        {/* Author + timestamp header */}
        {!isGrouped && (
          <div className="flex items-baseline gap-2 mb-0.5">
            <span className="text-raptor-text font-semibold text-sm">
              {author?.username ?? 'Unknown'}
            </span>
            <span className="text-raptor-faint text-xs">{formatTime(message.created_at)}</span>
            {message.edited_at && (
              <span className="text-raptor-faint text-[10px] italic">(edited)</span>
            )}
          </div>
        )}

        {/* Message text or edit field */}
        {editing ? (
          <div className="mt-1">
            <textarea
              value={editContent}
              onChange={e => setEditContent(e.target.value)}
              onKeyDown={handleEditKeyDown}
              rows={2}
              autoFocus
              className="w-full bg-raptor-pit border border-raptor-amber/40 text-raptor-text rounded-md px-3 py-2 text-sm outline-none resize-none focus:border-raptor-amber transition-colors font-body"
            />
            <div className="flex items-center gap-2 mt-1">
              <span className="text-raptor-faint text-xs">
                Enter to save · Esc to cancel
              </span>
              <button onClick={handleEdit}
                className="flex items-center gap-1 text-xs text-raptor-online hover:text-green-400 transition-colors">
                <Check size={12} /> Save
              </button>
              <button onClick={() => { setEditing(false); setEditContent(message.content) }}
                className="flex items-center gap-1 text-xs text-raptor-dnd hover:text-red-400 transition-colors">
                <X size={12} /> Cancel
              </button>
            </div>
          </div>
        ) : (
          <p className="text-raptor-text text-sm leading-relaxed break-words whitespace-pre-wrap">
            {message.content}
          </p>
        )}

        {/* Reactions */}
        {Object.keys(reactionGroups).length > 0 && (
          <div className="flex flex-wrap gap-1 mt-1.5">
            {Object.entries(reactionGroups).map(([emoji, users]) => {
              const reacted = users.includes(currentUser?.id)
              return (
                <button
                  key={emoji}
                  onClick={() => handleReact(emoji)}
                  className={`flex items-center gap-1 text-xs px-2 py-0.5 rounded-full border transition-colors ${
                    reacted
                      ? 'bg-raptor-amber/15 border-raptor-amber/40 text-raptor-amber'
                      : 'bg-raptor-surface border-raptor-border text-raptor-sub hover:border-raptor-muted hover:text-raptor-text'
                  }`}
                >
                  <span>{emoji}</span>
                  <span className="font-semibold">{users.length}</span>
                </button>
              )
            })}
          </div>
        )}
      </div>

      {/* Hover action buttons */}
      <div className="message-actions absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-0.5 bg-raptor-surface border border-raptor-border rounded-md px-1 py-0.5 shadow-lg">
        {/* React */}
        <div ref={emojiRef} className="relative">
          <ActionBtn onClick={() => setShowEmoji(!showEmoji)} title="Add reaction">
            <Smile size={14} />
          </ActionBtn>
          {showEmoji && (
            <div className="absolute right-0 bottom-full mb-1 z-50">
              <EmojiPicker onSelect={handleReact} onClose={() => setShowEmoji(false)} />
            </div>
          )}
        </div>

        {/* Edit (own messages only) */}
        {isOwn && !editing && (
          <ActionBtn onClick={() => setEditing(true)} title="Edit">
            <Pencil size={14} />
          </ActionBtn>
        )}

        {/* Delete (own messages only) */}
        {isOwn && (
          <ActionBtn onClick={handleDelete} title="Delete" danger>
            <Trash2 size={14} />
          </ActionBtn>
        )}
      </div>
    </div>
  )
}

function ActionBtn({ children, onClick, title, danger }) {
  return (
    <button
      onClick={onClick}
      title={title}
      className={`p-1 rounded transition-colors ${
        danger
          ? 'text-raptor-sub hover:text-raptor-dnd hover:bg-raptor-dnd/10'
          : 'text-raptor-sub hover:text-raptor-text hover:bg-raptor-raised'
      }`}
    >
      {children}
    </button>
  )
}
