// components/voice/VoiceChannelView.jsx
// Voice channel UI — shows participants and a "join" state.
// Full WebRTC is a large addition; this provides the UI scaffolding
// and a working mute/deafen toggle pattern that can be wired to WebRTC.

import { useState, useEffect } from 'react'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../context/AuthContext'
import Avatar from '../ui/Avatar'
import { Mic, MicOff, Headphones, PhoneOff, Volume2, Volume } from 'lucide-react'

export default function VoiceChannelView({ channel, members }) {
  const { profile }     = useAuth()
  const [joined, setJoined]   = useState(false)
  const [muted,  setMuted]    = useState(false)
  const [deaf,   setDeaf]     = useState(false)
  const [participants, setParticipants] = useState([])

  // Simulate participants with online members
  useEffect(() => {
    setParticipants(members.filter(m => m.status === 'online').slice(0, 4))
  }, [members])

  const handleJoin = () => setJoined(true)
  const handleLeave = () => { setJoined(false); setMuted(false); setDeaf(false) }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-raptor-border bg-raptor-abyss flex-shrink-0">
        <Volume2 size={18} className="text-raptor-faint flex-shrink-0" />
        <h2 className="text-raptor-text font-semibold text-sm">{channel.name}</h2>
        {joined && (
          <span className="ml-auto text-xs bg-raptor-online/15 border border-raptor-online/30 text-raptor-online px-2 py-0.5 rounded-full font-semibold">
            LIVE
          </span>
        )}
      </div>

      <div className="flex-1 flex flex-col items-center justify-center gap-6 p-8">
        {/* Participants */}
        {joined ? (
          <div className="w-full max-w-lg">
            <p className="text-raptor-faint text-xs font-semibold uppercase tracking-wider text-center mb-6">
              {participants.length + 1} in channel
            </p>
            <div className="flex flex-wrap gap-6 justify-center">
              {/* Self */}
              <ParticipantTile user={profile} muted={muted} speaking={!muted} self />
              {/* Others (simulated) */}
              {participants.map(m => (
                <ParticipantTile key={m.id} user={m} muted={false} speaking={Math.random() > 0.5} />
              ))}
            </div>
          </div>
        ) : (
          <div className="text-center">
            <div className="w-20 h-20 rounded-full bg-raptor-surface border-2 border-raptor-border flex items-center justify-center mb-6 mx-auto">
              <Volume2 size={36} className="text-raptor-faint" />
            </div>
            <h3 className="text-raptor-text font-semibold text-lg mb-1">{channel.name}</h3>
            <p className="text-raptor-sub text-sm mb-8">
              {participants.length > 0
                ? `${participants.length} ${participants.length === 1 ? 'person is' : 'people are'} already here`
                : 'No one is here yet — be the first to join!'}
            </p>
            {participants.length > 0 && (
              <div className="flex -space-x-2 justify-center mb-6">
                {participants.slice(0, 5).map(m => (
                  <Avatar key={m.id} user={m} size={32} className="border-2 border-raptor-abyss" />
                ))}
              </div>
            )}
          </div>
        )}

        {/* Controls */}
        <div className="flex items-center gap-3">
          {!joined ? (
            <button
              onClick={handleJoin}
              className="flex items-center gap-2.5 bg-raptor-online hover:bg-green-400 text-white font-semibold px-6 py-2.5 rounded-full transition-colors text-sm shadow-lg"
            >
              <Volume size={16} />
              Join Voice
            </button>
          ) : (
            <>
              <VoiceBtn
                active={!muted}
                onClick={() => setMuted(!muted)}
                label={muted ? 'Unmute' : 'Mute'}
              >
                {muted ? <MicOff size={20} /> : <Mic size={20} />}
              </VoiceBtn>

              <VoiceBtn
                active={!deaf}
                onClick={() => setDeaf(!deaf)}
                label={deaf ? 'Undeafen' : 'Deafen'}
              >
                {deaf ? <Volume size={20} /> : <Headphones size={20} />}
              </VoiceBtn>

              <button
                onClick={handleLeave}
                className="flex items-center gap-2 bg-raptor-dnd hover:bg-red-400 text-white font-semibold px-5 py-2.5 rounded-full transition-colors text-sm shadow-lg"
              >
                <PhoneOff size={16} />
                Disconnect
              </button>
            </>
          )}
        </div>

        <p className="text-raptor-faint text-xs text-center max-w-xs">
          {joined
            ? 'Full WebRTC support can be wired to the join/leave handlers in VoiceChannelView.jsx'
            : 'Voice channels use WebRTC for peer-to-peer audio. Click Join to connect.'}
        </p>
      </div>
    </div>
  )
}

function ParticipantTile({ user, muted, speaking, self }) {
  return (
    <div className="flex flex-col items-center gap-2">
      <div className={`relative rounded-full p-1 transition-all duration-200 ${
        speaking ? 'ring-2 ring-raptor-online ring-offset-2 ring-offset-raptor-abyss' : ''
      }`}>
        <Avatar user={user} size={64} />
        {muted && (
          <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-raptor-dnd rounded-full flex items-center justify-center border-2 border-raptor-abyss">
            <MicOff size={10} className="text-white" />
          </div>
        )}
      </div>
      <span className="text-raptor-text text-xs font-medium">
        {user?.username}{self ? ' (you)' : ''}
      </span>
    </div>
  )
}

function VoiceBtn({ children, active, onClick, label }) {
  return (
    <button
      onClick={onClick}
      title={label}
      className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors shadow-md ${
        active
          ? 'bg-raptor-surface border border-raptor-border text-raptor-text hover:bg-raptor-raised'
          : 'bg-raptor-dnd/20 border border-raptor-dnd/40 text-raptor-dnd hover:bg-raptor-dnd/30'
      }`}
    >
      {children}
    </button>
  )
}
