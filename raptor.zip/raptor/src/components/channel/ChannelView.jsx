// components/channel/ChannelView.jsx
// The main chat area for a text channel. Handles messages + realtime.

import { useState, useEffect, useRef, useCallback } from 'react'
import { useParams } from 'react-router-dom'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../context/AuthContext'
import MessageList  from '../message/MessageList'
import MessageInput from '../message/MessageInput'
import TypingIndicator from '../message/TypingIndicator'
import VoiceChannelView from '../voice/VoiceChannelView'
import { Hash, Volume2, Users, Pin } from 'lucide-react'

export default function ChannelView() {
  const { channelId } = useParams()
  const { profile }   = useAuth()

  const [channel,  setChannel]  = useState(null)
  const [messages, setMessages] = useState([])
  const [members,  setMembers]  = useState([])
  const [showMembers, setShowMembers] = useState(false)
  const [loading,  setLoading]  = useState(true)
  const bottomRef = useRef(null)

  // ── Fetch channel info ──────────────────────────────────────
  useEffect(() => {
    if (!channelId) return
    setLoading(true)
    setMessages([])

    supabase.from('channels').select('*').eq('id', channelId).single()
      .then(({ data }) => setChannel(data))

    fetchMessages()
    fetchMembers()
  }, [channelId])

  const fetchMessages = async () => {
    const { data } = await supabase
      .from('messages')
      .select(`*, author:users(id, username, avatar_url, status), reactions(*)`)
      .eq('channel_id', channelId)
      .order('created_at', { ascending: true })
      .limit(100)

    if (data) setMessages(data)
    setLoading(false)
    scrollToBottom(true)
  }

  const fetchMembers = async () => {
    if (!channel?.server_id && !channelId) return
    // Get server_id via the channel
    const { data: ch } = await supabase.from('channels').select('server_id').eq('id', channelId).single()
    if (!ch) return
    const { data } = await supabase
      .from('server_members')
      .select('user_id, role, users(id, username, avatar_url, status)')
      .eq('server_id', ch.server_id)
    if (data) setMembers(data.map(m => ({ ...m.users, role: m.role })))
  }

  // ── Realtime: new / updated / deleted messages ──────────────
  useEffect(() => {
    if (!channelId) return

    const ch = supabase
      .channel(`messages:${channelId}`)
      .on('postgres_changes', {
        event: 'INSERT', schema: 'public', table: 'messages',
        filter: `channel_id=eq.${channelId}`,
      }, async (payload) => {
        // Fetch full message with author + reactions
        const { data } = await supabase
          .from('messages')
          .select(`*, author:users(id, username, avatar_url, status), reactions(*)`)
          .eq('id', payload.new.id)
          .single()
        if (data) {
          setMessages(prev => [...prev, data])
          scrollToBottom()
        }
      })
      .on('postgres_changes', {
        event: 'UPDATE', schema: 'public', table: 'messages',
        filter: `channel_id=eq.${channelId}`,
      }, (payload) => {
        setMessages(prev => prev.map(m => m.id === payload.new.id ? { ...m, ...payload.new } : m))
      })
      .on('postgres_changes', {
        event: 'DELETE', schema: 'public', table: 'messages',
        filter: `channel_id=eq.${channelId}`,
      }, (payload) => {
        setMessages(prev => prev.filter(m => m.id !== payload.old.id))
      })
      // Reaction changes
      .on('postgres_changes', {
        event: '*', schema: 'public', table: 'reactions',
      }, () => {
        fetchMessages() // re-fetch to get updated reactions
      })
      .subscribe()

    return () => supabase.removeChannel(ch)
  }, [channelId])

  const scrollToBottom = (instant = false) => {
    setTimeout(() => {
      bottomRef.current?.scrollIntoView({ behavior: instant ? 'auto' : 'smooth' })
    }, 50)
  }

  const handleSend = async (content) => {
    if (!content.trim() || !profile) return
    await supabase.from('messages').insert({
      channel_id: channelId,
      author_id:  profile.id,
      content:    content.trim(),
    })
  }

  if (!channel) return null

  // Voice channel rendering
  if (channel.type === 'voice') {
    return <VoiceChannelView channel={channel} members={members} />
  }

  return (
    <div className="flex flex-col h-full">
      {/* ── Channel header ────────────────────────────────── */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-raptor-border bg-raptor-abyss flex-shrink-0 shadow-sm">
        <Hash size={18} className="text-raptor-faint flex-shrink-0" />
        <div className="flex-1 min-w-0">
          <h2 className="text-raptor-text font-semibold text-sm truncate">{channel.name}</h2>
          {channel.topic && (
            <p className="text-raptor-faint text-xs truncate">{channel.topic}</p>
          )}
        </div>
        <button
          onClick={() => setShowMembers(!showMembers)}
          className={`p-1.5 rounded transition-colors ${
            showMembers ? 'text-raptor-amber' : 'text-raptor-sub hover:text-raptor-text'
          }`}
          title="Toggle member list"
        >
          <Users size={18} />
        </button>
      </div>

      {/* ── Body: messages + optional member list ─────────── */}
      <div className="flex flex-1 min-h-0">
        {/* Messages */}
        <div className="flex flex-col flex-1 min-w-0 min-h-0">
          {loading ? (
            <div className="flex-1 flex items-center justify-center">
              <div className="flex gap-1.5">
                {[0,1,2].map(i => (
                  <div key={i} className="w-2 h-2 rounded-full bg-raptor-amber animate-bounce"
                    style={{ animationDelay: `${i*0.15}s` }} />
                ))}
              </div>
            </div>
          ) : (
            <MessageList messages={messages} currentUser={profile} channelId={channelId} />
          )}
          <div ref={bottomRef} />

          {/* Typing indicator */}
          <TypingIndicator channelId={channelId} currentUserId={profile?.id} />

          {/* Input */}
          <div className="flex-shrink-0 px-4 pb-4 pt-2">
            <MessageInput
              placeholder={`Message #${channel.name}`}
              onSend={handleSend}
              channelId={channelId}
              userId={profile?.id}
            />
          </div>
        </div>

        {/* Member list */}
        {showMembers && (
          <div className="w-56 flex-shrink-0 border-l border-raptor-border bg-raptor-dark overflow-y-auto">
            <MemberList members={members} />
          </div>
        )}
      </div>
    </div>
  )
}

function MemberList({ members }) {
  const online  = members.filter(m => m.status !== 'invisible')
  const offline = members.filter(m => m.status === 'invisible')

  return (
    <div className="p-3">
      {online.length > 0 && (
        <>
          <p className="text-raptor-faint text-xs font-semibold uppercase tracking-wider mb-2">
            Online — {online.length}
          </p>
          {online.map(m => <MemberRow key={m.id} member={m} />)}
        </>
      )}
      {offline.length > 0 && (
        <>
          <p className="text-raptor-faint text-xs font-semibold uppercase tracking-wider mt-4 mb-2">
            Offline — {offline.length}
          </p>
          {offline.map(m => <MemberRow key={m.id} member={m} offline />)}
        </>
      )}
    </div>
  )
}

function MemberRow({ member, offline }) {
  return (
    <div className={`flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-raptor-raised transition-colors cursor-default ${offline ? 'opacity-50' : ''}`}>
      <div className="relative flex-shrink-0">
        <div className="w-7 h-7 rounded-full bg-raptor-surface flex items-center justify-center text-xs font-bold text-raptor-sub">
          {member.username?.[0]?.toUpperCase()}
        </div>
        <span className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border border-raptor-dark ${
          member.status === 'online' ? 'bg-raptor-online' :
          member.status === 'idle'   ? 'bg-raptor-idle' :
          member.status === 'dnd'    ? 'bg-raptor-dnd' : 'bg-raptor-ghost'
        }`} />
      </div>
      <div className="min-w-0">
        <p className="text-raptor-text text-xs font-medium truncate">{member.username}</p>
        {member.role !== 'member' && (
          <p className="text-raptor-amber text-[10px] capitalize">{member.role}</p>
        )}
      </div>
    </div>
  )
}
