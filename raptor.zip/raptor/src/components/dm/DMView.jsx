// components/dm/DMView.jsx
// 1-on-1 direct message chat panel. Reuses MessageList + MessageInput.

import { useState, useEffect, useRef } from 'react'
import { useParams } from 'react-router-dom'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../context/AuthContext'
import MessageList     from '../message/MessageList'
import MessageInput    from '../message/MessageInput'
import TypingIndicator from '../message/TypingIndicator'
import Avatar          from '../ui/Avatar'
import StatusDot       from '../ui/StatusDot'

export default function DMView() {
  const { dmId }        = useParams()
  const { profile }     = useAuth()
  const [other, setOther]     = useState(null)
  const [messages, setMessages] = useState([])
  const [loading, setLoading]   = useState(true)
  const bottomRef = useRef(null)

  // Resolve the other user from the thread ID (two sorted UUIDs joined by _)
  useEffect(() => {
    if (!dmId || !profile) return
    setLoading(true)
    setMessages([])

    const ids = dmId.split('_')
    const otherId = ids.find(id => id !== profile.id)
    if (otherId) {
      supabase.from('users').select('*').eq('id', otherId).single()
        .then(({ data }) => setOther(data))
    }
    fetchMessages()
  }, [dmId, profile])

  const fetchMessages = async () => {
    const { data } = await supabase
      .from('messages')
      .select(`*, author:users(id, username, avatar_url, status), reactions(*)`)
      .eq('dm_id', dmId)
      .order('created_at', { ascending: true })
      .limit(100)
    if (data) setMessages(data)
    setLoading(false)
    scrollToBottom(true)
  }

  // Realtime subscription for DM messages
  useEffect(() => {
    if (!dmId) return
    const ch = supabase
      .channel(`dm:${dmId}`)
      .on('postgres_changes', {
        event: 'INSERT', schema: 'public', table: 'messages',
        filter: `dm_id=eq.${dmId}`,
      }, async (payload) => {
        const { data } = await supabase
          .from('messages')
          .select(`*, author:users(id, username, avatar_url, status), reactions(*)`)
          .eq('id', payload.new.id)
          .single()
        if (data) { setMessages(prev => [...prev, data]); scrollToBottom() }
      })
      .on('postgres_changes', {
        event: 'UPDATE', schema: 'public', table: 'messages',
        filter: `dm_id=eq.${dmId}`,
      }, (payload) => {
        setMessages(prev => prev.map(m => m.id === payload.new.id ? { ...m, ...payload.new } : m))
      })
      .on('postgres_changes', {
        event: 'DELETE', schema: 'public', table: 'messages',
        filter: `dm_id=eq.${dmId}`,
      }, (payload) => {
        setMessages(prev => prev.filter(m => m.id !== payload.old.id))
      })
      .on('postgres_changes', {
        event: '*', schema: 'public', table: 'reactions',
      }, fetchMessages)
      .subscribe()

    return () => supabase.removeChannel(ch)
  }, [dmId])

  // Track other user's status in realtime
  useEffect(() => {
    if (!other) return
    const ch = supabase
      .channel(`user_status:${other.id}`)
      .on('postgres_changes', {
        event: 'UPDATE', schema: 'public', table: 'users',
        filter: `id=eq.${other.id}`,
      }, (payload) => setOther(prev => ({ ...prev, ...payload.new })))
      .subscribe()
    return () => supabase.removeChannel(ch)
  }, [other?.id])

  const scrollToBottom = (instant = false) => {
    setTimeout(() => {
      bottomRef.current?.scrollIntoView({ behavior: instant ? 'auto' : 'smooth' })
    }, 50)
  }

  const handleSend = async (content) => {
    if (!profile) return
    await supabase.from('messages').insert({
      dm_id:     dmId,
      author_id: profile.id,
      content:   content.trim(),
    })
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-raptor-border bg-raptor-abyss flex-shrink-0 shadow-sm">
        {other ? (
          <>
            <div className="relative flex-shrink-0">
              <Avatar user={other} size={34} />
              <StatusDot status={other.status} className="absolute -bottom-0.5 -right-0.5" />
            </div>
            <div>
              <h2 className="text-raptor-text font-semibold text-sm">{other.username}</h2>
              <p className="text-raptor-faint text-xs capitalize">{other.status}</p>
            </div>
          </>
        ) : (
          <div className="h-8 w-32 bg-raptor-surface rounded animate-pulse" />
        )}
      </div>

      {/* Messages */}
      <div className="flex flex-col flex-1 min-h-0">
        {loading ? (
          <div className="flex-1 flex items-center justify-center">
            <div className="flex gap-1.5">
              {[0,1,2].map(i => (
                <div key={i} className="w-2 h-2 rounded-full bg-raptor-amber animate-bounce"
                  style={{ animationDelay: `${i*0.15}s` }} />
              ))}
            </div>
          </div>
        ) : (
          <>
            {/* DM intro banner */}
            {messages.length === 0 && other && (
              <div className="px-4 py-8 text-center">
                <Avatar user={other} size={64} className="mx-auto mb-3" />
                <h3 className="text-raptor-text font-semibold mb-1">
                  This is the start of your conversation with <span className="text-raptor-amber">{other.username}</span>
                </h3>
                <p className="text-raptor-faint text-sm">Send a message to get started.</p>
              </div>
            )}
            <MessageList messages={messages} currentUser={profile} channelId={dmId} />
          </>
        )}
        <div ref={bottomRef} />
        <TypingIndicator channelId={dmId} currentUserId={profile?.id} />
        <div className="flex-shrink-0 px-4 pb-4 pt-2">
          <MessageInput
            placeholder={`Message ${other?.username ?? '…'}`}
            onSend={handleSend}
            channelId={dmId}
            userId={profile?.id}
          />
        </div>
      </div>
    </div>
  )
}
