// components/dm/DMSidebar.jsx
// Lists existing DM conversations and lets users search for new ones.

import { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { supabase } from '../../lib/supabase'
import Avatar from '../ui/Avatar'
import StatusDot from '../ui/StatusDot'
import { Search, MessageSquare, X } from 'lucide-react'

export default function DMSidebar({ profile }) {
  const navigate      = useNavigate()
  const { dmId }      = useParams()
  const [threads, setThreads]     = useState([])
  const [search,  setSearch]      = useState('')
  const [results, setResults]     = useState([])
  const [searching, setSearching] = useState(false)

  // Fetch existing DM threads
  useEffect(() => {
    if (!profile) return
    fetchThreads()
  }, [profile])

  const fetchThreads = async () => {
    const { data } = await supabase
      .from('dm_threads')
      .select('*, user_a:users!dm_threads_user_a_fkey(*), user_b:users!dm_threads_user_b_fkey(*)')
      .or(`user_a.eq.${profile.id},user_b.eq.${profile.id}`)
      .order('created_at', { ascending: false })
    setThreads(data ?? [])
  }

  // Search users to start a new DM
  useEffect(() => {
    if (!search.trim()) { setResults([]); return }
    const t = setTimeout(async () => {
      setSearching(true)
      const { data } = await supabase
        .from('users')
        .select('*')
        .ilike('username', `%${search}%`)
        .neq('id', profile.id)
        .limit(8)
      setResults(data ?? [])
      setSearching(false)
    }, 300)
    return () => clearTimeout(t)
  }, [search, profile])

  const openDM = async (otherUser) => {
    // Create a deterministic DM thread ID from both user IDs (sorted)
    const ids = [profile.id, otherUser.id].sort()
    const threadId = ids.join('_')

    // Upsert thread row
    await supabase.from('dm_threads').upsert(
      { id: threadId, user_a: ids[0], user_b: ids[1] },
      { onConflict: 'id' }
    )

    setSearch('')
    await fetchThreads()
    navigate(`/dm/${threadId}`)
  }

  const getOtherUser = (thread) =>
    thread.user_a?.id === profile?.id ? thread.user_b : thread.user_a

  return (
    <div className="flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="px-3 pt-4 pb-2 flex-shrink-0">
        <div className="flex items-center gap-2 mb-3">
          <MessageSquare size={16} className="text-raptor-amber" />
          <h2 className="text-raptor-text font-semibold text-sm">Direct Messages</h2>
        </div>
        {/* Search input */}
        <div className="relative">
          <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-raptor-faint" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Find or start a DM"
            className="w-full bg-raptor-pit border border-raptor-border text-raptor-text text-xs rounded-md pl-7 pr-7 py-1.5 outline-none focus:border-raptor-amber/50 placeholder:text-raptor-faint transition-colors"
          />
          {search && (
            <button onClick={() => setSearch('')} className="absolute right-2 top-1/2 -translate-y-1/2 text-raptor-faint hover:text-raptor-sub">
              <X size={12} />
            </button>
          )}
        </div>
      </div>

      {/* Search results dropdown */}
      {search && (
        <div className="mx-3 mb-2 bg-raptor-surface border border-raptor-border rounded-md overflow-hidden flex-shrink-0 animate-slide-up shadow-xl">
          {searching && (
            <p className="text-raptor-faint text-xs px-3 py-2">Searching…</p>
          )}
          {!searching && results.length === 0 && (
            <p className="text-raptor-faint text-xs px-3 py-2">No users found</p>
          )}
          {results.map(user => (
            <button
              key={user.id}
              onClick={() => openDM(user)}
              className="w-full flex items-center gap-2.5 px-3 py-2 hover:bg-raptor-raised transition-colors text-left"
            >
              <div className="relative flex-shrink-0">
                <Avatar user={user} size={28} />
                <StatusDot status={user.status} className="absolute -bottom-0.5 -right-0.5 border-raptor-surface" />
              </div>
              <span className="text-raptor-text text-sm font-medium">{user.username}</span>
            </button>
          ))}
        </div>
      )}

      {/* Thread list */}
      <div className="flex-1 overflow-y-auto px-2">
        <p className="text-raptor-faint text-[10px] font-semibold uppercase tracking-wider px-2 mb-1">
          Recent
        </p>
        {threads.length === 0 && (
          <p className="text-raptor-faint text-xs px-2 py-2">No conversations yet. Search for a user above.</p>
        )}
        {threads.map(thread => {
          const other  = getOtherUser(thread)
          const isActive = dmId === thread.id
          return (
            <button
              key={thread.id}
              onClick={() => navigate(`/dm/${thread.id}`)}
              className={`w-full flex items-center gap-2.5 px-2 py-2 rounded-md transition-colors text-left mb-0.5 ${
                isActive
                  ? 'bg-raptor-raised text-raptor-text'
                  : 'hover:bg-raptor-dark text-raptor-sub hover:text-raptor-text'
              }`}
            >
              <div className="relative flex-shrink-0">
                <Avatar user={other} size={32} />
                <StatusDot status={other?.status} className="absolute -bottom-0.5 -right-0.5" />
              </div>
              <span className="text-sm font-medium truncate">{other?.username}</span>
            </button>
          )
        })}
      </div>
    </div>
  )
}
