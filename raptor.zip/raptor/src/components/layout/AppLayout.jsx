// components/layout/AppLayout.jsx
// The main three-column layout: server rail | sidebar | main content

import { useState, useEffect } from 'react'
import { Routes, Route } from 'react-router-dom'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../context/AuthContext'
import ServerRail    from '../server/ServerRail'
import ServerSidebar from '../server/ServerSidebar'
import ChannelView   from '../channel/ChannelView'
import DMSidebar     from '../dm/DMSidebar'
import DMView        from '../dm/DMView'
import UserPanel     from './UserPanel'
import WelcomeView   from './WelcomeView'
import { MessageSquare } from 'lucide-react'

export default function AppLayout() {
  const { profile } = useAuth()
  const [servers, setServers]         = useState([])
  const [activeServer, setActiveServer] = useState(null)
  const [dmOpen, setDmOpen]           = useState(false)  // DM mode vs server mode

  // Fetch all servers the user belongs to
  const fetchServers = async () => {
    if (!profile) return
    const { data } = await supabase
      .from('server_members')
      .select('server_id, servers(*)')
      .eq('user_id', profile.id)
    if (data) setServers(data.map(d => d.servers))
  }

  useEffect(() => { fetchServers() }, [profile])

  // Subscribe to server_members changes (join/leave)
  useEffect(() => {
    if (!profile) return
    const ch = supabase
      .channel('server_member_changes')
      .on('postgres_changes', {
        event: '*', schema: 'public', table: 'server_members',
        filter: `user_id=eq.${profile.id}`,
      }, fetchServers)
      .subscribe()
    return () => supabase.removeChannel(ch)
  }, [profile])

  return (
    <div className="h-full flex bg-raptor-void overflow-hidden">
      {/* ── Server Rail (leftmost column) ─────────────────── */}
      <ServerRail
        servers={servers}
        activeServer={activeServer}
        dmOpen={dmOpen}
        onSelectServer={(s) => { setActiveServer(s); setDmOpen(false) }}
        onSelectDM={() => { setActiveServer(null); setDmOpen(true) }}
        onServersChange={fetchServers}
      />

      {/* ── Sidebar (channel list or DM list) ─────────────── */}
      <div className="w-60 flex-shrink-0 bg-raptor-dark flex flex-col border-r border-raptor-border">
        {dmOpen ? (
          <DMSidebar profile={profile} />
        ) : activeServer ? (
          <ServerSidebar server={activeServer} onServerUpdate={fetchServers} />
        ) : (
          <BlankSidebar />
        )}
        {/* User panel always visible at the bottom */}
        <UserPanel />
      </div>

      {/* ── Main content area ──────────────────────────────── */}
      <div className="flex-1 flex flex-col min-w-0 bg-raptor-abyss">
        <Routes>
          <Route path="/" element={<WelcomeView />} />
          <Route path="/channels/:serverId/:channelId" element={<ChannelView />} />
          <Route path="/dm/:dmId" element={<DMView />} />
          <Route path="*" element={<WelcomeView />} />
        </Routes>
      </div>
    </div>
  )
}

function BlankSidebar() {
  return (
    <div className="flex-1 flex items-center justify-center text-raptor-faint">
      <div className="text-center">
        <MessageSquare size={32} className="mx-auto mb-2 opacity-30" />
        <p className="text-xs">Select a server</p>
      </div>
    </div>
  )
}
