// components/layout/UserPanel.jsx
// Shows the current user's avatar, username, and quick settings.

import { useState, useRef } from 'react'
import { useAuth } from '../../context/AuthContext'
import { supabase } from '../../lib/supabase'
import { Mic, Headphones, Settings, LogOut, Circle } from 'lucide-react'
import Avatar from '../ui/Avatar'
import StatusDot from '../ui/StatusDot'

const STATUS_OPTIONS = [
  { value: 'online',    label: 'Online',    color: 'bg-raptor-online' },
  { value: 'idle',      label: 'Idle',      color: 'bg-raptor-idle' },
  { value: 'dnd',       label: 'Do Not Disturb', color: 'bg-raptor-dnd' },
  { value: 'invisible', label: 'Invisible', color: 'bg-raptor-ghost' },
]

export default function UserPanel() {
  const { profile, signOut } = useAuth()
  const [showMenu, setShowMenu] = useState(false)
  const [muted, setMuted]       = useState(false)
  const [deafened, setDeafened] = useState(false)

  if (!profile) return null

  const setStatus = async (status) => {
    await supabase.from('users').update({ status }).eq('id', profile.id)
    setShowMenu(false)
  }

  return (
    <div className="relative flex-shrink-0 bg-raptor-pit border-t border-raptor-border px-2 py-2">
      {/* Status menu */}
      {showMenu && (
        <div className="absolute bottom-full left-2 right-2 mb-1 bg-raptor-surface border border-raptor-border rounded-lg shadow-2xl overflow-hidden animate-slide-up z-50">
          <div className="p-1.5 border-b border-raptor-border">
            <p className="text-raptor-faint text-xs uppercase tracking-wider font-semibold px-2 py-1">
              Set Status
            </p>
            {STATUS_OPTIONS.map(opt => (
              <button
                key={opt.value}
                onClick={() => setStatus(opt.value)}
                className="w-full flex items-center gap-2.5 px-2 py-1.5 rounded hover:bg-raptor-raised text-sm text-raptor-text transition-colors"
              >
                <span className={`w-2.5 h-2.5 rounded-full ${opt.color} flex-shrink-0`} />
                {opt.label}
              </button>
            ))}
          </div>
          <div className="p-1.5">
            <button
              onClick={signOut}
              className="w-full flex items-center gap-2.5 px-2 py-1.5 rounded hover:bg-raptor-dnd/20 text-sm text-raptor-dnd transition-colors"
            >
              <LogOut size={14} />
              Log Out
            </button>
          </div>
        </div>
      )}

      <div className="flex items-center gap-2">
        {/* Avatar + name (click to open menu) */}
        <button
          onClick={() => setShowMenu(!showMenu)}
          className="flex items-center gap-2 flex-1 min-w-0 rounded-md hover:bg-raptor-raised px-1.5 py-1 transition-colors text-left"
        >
          <div className="relative flex-shrink-0">
            <Avatar user={profile} size={32} />
            <StatusDot status={profile.status} className="absolute -bottom-0.5 -right-0.5" />
          </div>
          <div className="min-w-0">
            <p className="text-raptor-text text-sm font-semibold truncate leading-tight">
              {profile.username}
            </p>
            <p className="text-raptor-faint text-xs truncate capitalize leading-tight">
              {profile.status}
            </p>
          </div>
        </button>

        {/* Voice controls */}
        <div className="flex items-center gap-0.5">
          <IconBtn
            active={!muted}
            onClick={() => setMuted(!muted)}
            title={muted ? 'Unmute' : 'Mute'}
          >
            <Mic size={15} />
          </IconBtn>
          <IconBtn
            active={!deafened}
            onClick={() => setDeafened(!deafened)}
            title={deafened ? 'Undeafen' : 'Deafen'}
          >
            <Headphones size={15} />
          </IconBtn>
        </div>
      </div>
    </div>
  )
}

function IconBtn({ children, active, onClick, title }) {
  return (
    <button
      onClick={onClick}
      title={title}
      className={`p-1.5 rounded transition-colors ${
        active
          ? 'text-raptor-sub hover:text-raptor-text hover:bg-raptor-raised'
          : 'text-raptor-dnd hover:bg-raptor-raised'
      }`}
    >
      {children}
    </button>
  )
}
