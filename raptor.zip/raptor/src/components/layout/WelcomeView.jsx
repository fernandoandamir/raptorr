// components/layout/WelcomeView.jsx
import { Zap } from 'lucide-react'

export default function WelcomeView() {
  return (
    <div className="flex-1 flex items-center justify-center h-full">
      <div className="text-center animate-fade-in">
        <div className="inline-flex items-center gap-2 mb-4">
          <div className="w-12 h-12 bg-raptor-amber/10 border border-raptor-amber/20 rounded-lg flex items-center justify-center">
            <Zap size={24} className="text-raptor-amber" />
          </div>
        </div>
        <div className="raptor-logo text-4xl text-raptor-amber tracking-widest mb-2">RAPTOR</div>
        <p className="text-raptor-sub text-sm max-w-xs mx-auto">
          Select a channel or open a direct message to start talking.
        </p>
      </div>
    </div>
  )
}
