// components/ui/Tooltip.jsx
import { useState } from 'react'

export default function Tooltip({ content, children, side = 'top' }) {
  const [visible, setVisible] = useState(false)

  const posClass = {
    top:   'bottom-full left-1/2 -translate-x-1/2 mb-2',
    right: 'left-full top-1/2 -translate-y-1/2 ml-2',
    left:  'right-full top-1/2 -translate-y-1/2 mr-2',
    bottom:'top-full left-1/2 -translate-x-1/2 mt-2',
  }[side]

  return (
    <div className="relative flex items-center justify-center"
      onMouseEnter={() => setVisible(true)}
      onMouseLeave={() => setVisible(false)}
    >
      {children}
      {visible && (
        <div className={`absolute z-50 px-2 py-1 bg-raptor-void border border-raptor-border text-raptor-text text-xs rounded whitespace-nowrap pointer-events-none animate-fade-in ${posClass}`}>
          {content}
        </div>
      )}
    </div>
  )
}
