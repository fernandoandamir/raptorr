// components/ui/StatusDot.jsx
export default function StatusDot({ status, className = '' }) {
  const colors = {
    online:    'bg-raptor-online',
    idle:      'bg-raptor-idle',
    dnd:       'bg-raptor-dnd',
    invisible: 'bg-raptor-ghost',
  }
  return (
    <span
      className={`w-3 h-3 rounded-full border-2 border-raptor-dark flex-shrink-0 ${
        colors[status] ?? 'bg-raptor-ghost'
      } ${className}`}
    />
  )
}
