// components/ui/Avatar.jsx
// Renders a user avatar or a colourful generated initial.

const COLORS = [
  'bg-amber-600', 'bg-sky-600', 'bg-emerald-600',
  'bg-violet-600', 'bg-rose-600', 'bg-teal-600',
]

function colorFor(str = '') {
  let hash = 0
  for (const c of str) hash = c.charCodeAt(0) + ((hash << 5) - hash)
  return COLORS[Math.abs(hash) % COLORS.length]
}

export default function Avatar({ user, size = 36, className = '' }) {
  const dim = `${size}px`
  if (user?.avatar_url) {
    return (
      <img
        src={user.avatar_url}
        alt={user.username}
        style={{ width: dim, height: dim }}
        className={`rounded-full object-cover flex-shrink-0 ${className}`}
      />
    )
  }
  const initial = (user?.username || '?')[0].toUpperCase()
  const bg = colorFor(user?.username)
  return (
    <div
      style={{ width: dim, height: dim, fontSize: size * 0.4 }}
      className={`${bg} rounded-full flex items-center justify-center font-bold text-white flex-shrink-0 select-none ${className}`}
    >
      {initial}
    </div>
  )
}
