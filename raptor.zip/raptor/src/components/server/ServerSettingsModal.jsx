// components/server/ServerSettingsModal.jsx
import { useState } from 'react'
import { supabase } from '../../lib/supabase'
import Modal from '../ui/Modal'

export default function ServerSettingsModal({ server, onClose, onUpdated }) {
  const [name, setName]     = useState(server.name)
  const [error, setError]   = useState('')
  const [loading, setLoading] = useState(false)
  const [saved, setSaved]   = useState(false)

  const handleSave = async (e) => {
    e.preventDefault()
    setLoading(true)
    const { error } = await supabase
      .from('servers').update({ name }).eq('id', server.id)
    if (error) { setError(error.message) }
    else { setSaved(true); onUpdated(); setTimeout(() => setSaved(false), 2000) }
    setLoading(false)
  }

  return (
    <Modal title={`Settings — ${server.name}`} onClose={onClose}>
      <form onSubmit={handleSave} className="space-y-4">
        <div>
          <label className="block text-raptor-sub text-xs font-semibold uppercase tracking-wider mb-1.5">
            Server Name
          </label>
          <input
            value={name}
            onChange={e => setName(e.target.value)}
            className="w-full bg-raptor-pit border border-raptor-border text-raptor-text rounded-md px-3 py-2 text-sm outline-none focus:border-raptor-amber transition-colors"
          />
        </div>

        <div className="bg-raptor-pit border border-raptor-border rounded-md p-3">
          <p className="text-raptor-sub text-xs font-semibold uppercase tracking-wider mb-1">Invite Code</p>
          <p className="font-mono text-raptor-amber text-sm">{server.invite_code}</p>
          <p className="text-raptor-faint text-xs mt-1">Share this code so others can join.</p>
        </div>

        {error  && <p className="text-raptor-dnd text-sm">{error}</p>}
        {saved  && <p className="text-raptor-online text-sm">Saved!</p>}

        <div className="flex justify-end gap-3 pt-2">
          <button type="button" onClick={onClose}
            className="px-4 py-2 text-sm text-raptor-sub hover:text-raptor-text transition-colors">
            Close
          </button>
          <button type="submit" disabled={loading}
            className="px-5 py-2 bg-raptor-amber text-raptor-void text-sm font-semibold rounded-md hover:bg-raptor-gold transition-colors disabled:opacity-50">
            {loading ? 'Saving…' : 'Save Changes'}
          </button>
        </div>
      </form>
    </Modal>
  )
}
