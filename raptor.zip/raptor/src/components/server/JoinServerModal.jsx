// components/server/JoinServerModal.jsx
import { useState } from 'react'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../context/AuthContext'
import Modal from '../ui/Modal'

export default function JoinServerModal({ onClose, onJoined }) {
  const { profile } = useAuth()
  const [code, setCode]     = useState('')
  const [error, setError]   = useState('')
  const [loading, setLoading] = useState(false)

  const handleJoin = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    // Look up the server by invite code
    const { data: server, error: sErr } = await supabase
      .from('servers')
      .select('*')
      .eq('invite_code', code.trim().toLowerCase())
      .single()

    if (sErr || !server) { setError('Invalid invite code.'); setLoading(false); return }

    // Already a member?
    const { data: existing } = await supabase
      .from('server_members')
      .select('user_id')
      .eq('server_id', server.id)
      .eq('user_id', profile.id)
      .single()

    if (existing) { onJoined(server); return }

    // Join
    const { error: mErr } = await supabase.from('server_members').insert({
      server_id: server.id, user_id: profile.id, role: 'member'
    })

    if (mErr) { setError(mErr.message); setLoading(false); return }
    onJoined(server)
  }

  return (
    <Modal title="Join a Server" onClose={onClose}>
      <p className="text-raptor-sub text-sm mb-4">
        Enter an invite code to join an existing server.
      </p>
      <form onSubmit={handleJoin} className="space-y-4">
        <div>
          <label className="block text-raptor-sub text-xs font-semibold uppercase tracking-wider mb-1.5">
            Invite Code
          </label>
          <input
            autoFocus
            value={code}
            onChange={e => setCode(e.target.value)}
            placeholder="e.g. a1b2c3d4"
            className="w-full bg-raptor-pit border border-raptor-border text-raptor-text rounded-md px-3 py-2 text-sm outline-none focus:border-raptor-amber transition-colors font-mono"
          />
        </div>
        {error && <p className="text-raptor-dnd text-sm">{error}</p>}
        <div className="flex gap-3 justify-end pt-2">
          <button type="button" onClick={onClose}
            className="px-4 py-2 text-sm text-raptor-sub hover:text-raptor-text transition-colors">
            Cancel
          </button>
          <button type="submit" disabled={loading || !code.trim()}
            className="px-5 py-2 bg-raptor-amber text-raptor-void text-sm font-semibold rounded-md hover:bg-raptor-gold transition-colors disabled:opacity-50">
            {loading ? 'Joining…' : 'Join Server'}
          </button>
        </div>
      </form>
    </Modal>
  )
}
