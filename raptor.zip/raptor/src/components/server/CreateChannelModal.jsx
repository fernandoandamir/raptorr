// components/server/CreateChannelModal.jsx
import { useState } from 'react'
import { supabase } from '../../lib/supabase'
import Modal from '../ui/Modal'
import { Hash, Volume2 } from 'lucide-react'

export default function CreateChannelModal({ server, defaultType = 'text', onClose, onCreated }) {
  const [name, setName]     = useState('')
  const [type, setType]     = useState(defaultType)
  const [error, setError]   = useState('')
  const [loading, setLoading] = useState(false)

  const handleCreate = async (e) => {
    e.preventDefault()
    if (!name.trim()) return
    setLoading(true)
    const { data, error } = await supabase
      .from('channels')
      .insert({ server_id: server.id, name: name.toLowerCase().replace(/\s+/g, '-'), type })
      .select()
      .single()
    if (error) { setError(error.message); setLoading(false); return }
    onCreated(data)
  }

  return (
    <Modal title="Create Channel" onClose={onClose}>
      <form onSubmit={handleCreate} className="space-y-4">
        <div>
          <label className="block text-raptor-sub text-xs font-semibold uppercase tracking-wider mb-2">
            Channel Type
          </label>
          <div className="grid grid-cols-2 gap-2">
            {[
              { value: 'text',  Icon: Hash,     label: 'Text' },
              { value: 'voice', Icon: Volume2,  label: 'Voice' },
            ].map(({ value, Icon, label }) => (
              <button
                key={value}
                type="button"
                onClick={() => setType(value)}
                className={`flex items-center gap-2 p-3 rounded-md border transition-colors text-sm ${
                  type === value
                    ? 'border-raptor-amber bg-raptor-amber/10 text-raptor-amber'
                    : 'border-raptor-border text-raptor-sub hover:border-raptor-muted'
                }`}
              >
                <Icon size={16} />
                {label}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-raptor-sub text-xs font-semibold uppercase tracking-wider mb-1.5">
            Channel Name
          </label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-raptor-faint">
              {type === 'voice' ? <Volume2 size={14} /> : <Hash size={14} />}
            </span>
            <input
              autoFocus
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder={type === 'voice' ? 'General Voice' : 'general'}
              className="w-full bg-raptor-pit border border-raptor-border text-raptor-text rounded-md pl-8 pr-3 py-2 text-sm outline-none focus:border-raptor-amber transition-colors"
            />
          </div>
        </div>

        {error && <p className="text-raptor-dnd text-sm">{error}</p>}

        <div className="flex gap-3 justify-end pt-2">
          <button type="button" onClick={onClose}
            className="px-4 py-2 text-sm text-raptor-sub hover:text-raptor-text transition-colors">
            Cancel
          </button>
          <button type="submit" disabled={loading || !name.trim()}
            className="px-5 py-2 bg-raptor-amber text-raptor-void text-sm font-semibold rounded-md hover:bg-raptor-gold transition-colors disabled:opacity-50">
            {loading ? 'Creating…' : 'Create Channel'}
          </button>
        </div>
      </form>
    </Modal>
  )
}
