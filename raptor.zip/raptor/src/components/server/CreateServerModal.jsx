// components/server/CreateServerModal.jsx
import { useState } from 'react'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../context/AuthContext'
import Modal from '../ui/Modal'

export default function CreateServerModal({ onClose, onCreated }) {
  const { profile } = useAuth()
  const [name, setName]     = useState('')
  const [error, setError]   = useState('')
  const [loading, setLoading] = useState(false)

  const handleCreate = async (e) => {
    e.preventDefault()
    if (!name.trim()) return
    setLoading(true)
    setError('')

    // 1. Create the server
    const { data: server, error: sErr } = await supabase
      .from('servers')
      .insert({ name: name.trim(), owner_id: profile.id })
      .select()
      .single()

    if (sErr) { setError(sErr.message); setLoading(false); return }

    // 2. Add owner as member
    await supabase.from('server_members').insert({
      server_id: server.id, user_id: profile.id, role: 'owner'
    })

    // 3. Create a default #general text channel
    await supabase.from('channels').insert({
      server_id: server.id, name: 'general', type: 'text', position: 0
    })

    onCreated(server)
  }

  return (
    <Modal title="Create a Server" onClose={onClose}>
      <form onSubmit={handleCreate} className="space-y-4">
        <div>
          <label className="block text-raptor-sub text-xs font-semibold uppercase tracking-wider mb-1.5">
            Server Name
          </label>
          <input
            autoFocus
            value={name}
            onChange={e => setName(e.target.value)}
            placeholder="My Awesome Server"
            className="w-full bg-raptor-pit border border-raptor-border text-raptor-text rounded-md px-3 py-2 text-sm outline-none focus:border-raptor-amber transition-colors"
          />
        </div>
        {error && <p className="text-raptor-dnd text-sm">{error}</p>}
        <div className="flex gap-3 justify-end pt-2">
          <button type="button" onClick={onClose}
            className="px-4 py-2 text-sm text-raptor-sub hover:text-raptor-text transition-colors">
            Cancel
          </button>
          <button type="submit" disabled={loading || !name.trim()}
            className="px-5 py-2 bg-raptor-amber text-raptor-void text-sm font-semibold rounded-md hover:bg-raptor-gold transition-colors disabled:opacity-50">
            {loading ? 'Creating…' : 'Create'}
          </button>
        </div>
      </form>
    </Modal>
  )
}
