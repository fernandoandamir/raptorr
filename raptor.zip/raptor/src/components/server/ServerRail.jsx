// components/server/ServerRail.jsx
// The far-left column that shows server icons + DM + create/join buttons.

import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { MessageSquare, Plus, Compass, Zap } from 'lucide-react'
import CreateServerModal from './CreateServerModal'
import JoinServerModal   from './JoinServerModal'
import Tooltip           from '../ui/Tooltip'

export default function ServerRail({
  servers, activeServer, dmOpen,
  onSelectServer, onSelectDM, onServersChange
}) {
  const navigate = useNavigate()
  const [showCreate, setShowCreate] = useState(false)
  const [showJoin, setShowJoin]     = useState(false)

  const handleServerClick = (server) => {
    onSelectServer(server)
    navigate('/')
  }

  return (
    <div className="w-[72px] flex-shrink-0 bg-raptor-void flex flex-col items-center py-3 gap-2 border-r border-raptor-border overflow-y-auto">
      {/* Logo */}
      <Tooltip content="RAPTOR" side="right">
        <button
          onClick={() => { onSelectDM(); navigate('/') }}
          className="w-12 h-12 bg-raptor-amber rounded-xl flex items-center justify-center hover:rounded-2xl transition-all duration-150 flex-shrink-0 amber-glow"
        >
          <Zap size={22} className="text-raptor-void" fill="currentColor" />
        </button>
      </Tooltip>

      <Divider />

      {/* DM button */}
      <Tooltip content="Direct Messages" side="right">
        <button
          onClick={() => { onSelectDM(); navigate('/') }}
          className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-150 flex-shrink-0 ${
            dmOpen
              ? 'bg-raptor-amber text-raptor-void rounded-xl amber-glow'
              : 'bg-raptor-dark text-raptor-sub hover:bg-raptor-raised hover:text-raptor-text hover:rounded-xl'
          }`}
        >
          <MessageSquare size={20} />
        </button>
      </Tooltip>

      <Divider />

      {/* Server list */}
      {servers.map(server => (
        <Tooltip key={server.id} content={server.name} side="right">
          <button
            onClick={() => handleServerClick(server)}
            className={`relative w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-150 flex-shrink-0 font-bold text-sm overflow-hidden ${
              activeServer?.id === server.id
                ? 'rounded-xl bg-raptor-amber text-raptor-void amber-glow'
                : 'bg-raptor-dark text-raptor-sub hover:rounded-xl hover:bg-raptor-surface hover:text-raptor-text'
            }`}
          >
            {/* Active indicator bar */}
            {activeServer?.id === server.id && (
              <span className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-raptor-amber rounded-r" />
            )}
            {server.icon_url
              ? <img src={server.icon_url} alt={server.name} className="w-full h-full object-cover" />
              : <span>{server.name[0].toUpperCase()}</span>
            }
          </button>
        </Tooltip>
      ))}

      <Divider />

      {/* Create server */}
      <Tooltip content="Create Server" side="right">
        <button
          onClick={() => setShowCreate(true)}
          className="w-12 h-12 rounded-2xl bg-raptor-dark text-raptor-online hover:bg-raptor-online hover:text-white hover:rounded-xl transition-all duration-150 flex items-center justify-center flex-shrink-0"
        >
          <Plus size={22} />
        </button>
      </Tooltip>

      {/* Join server */}
      <Tooltip content="Join Server" side="right">
        <button
          onClick={() => setShowJoin(true)}
          className="w-12 h-12 rounded-2xl bg-raptor-dark text-raptor-sub hover:bg-raptor-raised hover:text-raptor-text hover:rounded-xl transition-all duration-150 flex items-center justify-center flex-shrink-0"
        >
          <Compass size={20} />
        </button>
      </Tooltip>

      {showCreate && (
        <CreateServerModal
          onClose={() => setShowCreate(false)}
          onCreated={(server) => { onServersChange(); onSelectServer(server); setShowCreate(false) }}
        />
      )}
      {showJoin && (
        <JoinServerModal
          onClose={() => setShowJoin(false)}
          onJoined={(server) => { onServersChange(); onSelectServer(server); setShowJoin(false) }}
        />
      )}
    </div>
  )
}

function Divider() {
  return <div className="w-8 h-px bg-raptor-border flex-shrink-0" />
}
