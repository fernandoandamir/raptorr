// components/server/ServerSidebar.jsx
// Shows the server name, channel list, and management options.

import { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../context/AuthContext'
import {
  Hash, Volume2, Plus, Settings, ChevronDown,
  Copy, LogOut, Trash2, UserPlus
} from 'lucide-react'
import CreateChannelModal  from './CreateChannelModal'
import ServerSettingsModal from './ServerSettingsModal'

export default function ServerSidebar({ server, onServerUpdate }) {
  const { profile }   = useAuth()
  const navigate      = useNavigate()
  const { channelId } = useParams()

  const [channels, setChannels]       = useState([])
  const [members, setMembers]         = useState([])
  const [showMenu, setShowMenu]       = useState(false)
  const [showCreateCh, setShowCreateCh] = useState(false)
  const [showSettings, setShowSettings] = useState(false)
  const [isOwner, setIsOwner]         = useState(false)
  const [copied, setCopied]           = useState(false)

  const fetchChannels = async () => {
    const { data } = await supabase
      .from('channels')
      .select('*')
      .eq('server_id', server.id)
      .order('position')
    setChannels(data ?? [])
  }

  const fetchMembers = async () => {
    const { data } = await supabase
      .from('server_members')
      .select('*, users(*)')
      .eq('server_id', server.id)
    setMembers(data ?? [])
    const me = data?.find(m => m.user_id === profile?.id)
    setIsOwner(me?.role === 'owner')
  }

  useEffect(() => {
    if (!server) return
    fetchChannels()
    fetchMembers()
  }, [server?.id])

  // Realtime: channel changes
  useEffect(() => {
    if (!server) return
    const ch = supabase
      .channel(`channels:${server.id}`)
      .on('postgres_changes', {
        event: '*', schema: 'public', table: 'channels',
        filter: `server_id=eq.${server.id}`
      }, fetchChannels)
      .subscribe()
    return () => supabase.removeChannel(ch)
  }, [server?.id])

  const copyInvite = () => {
    navigator.clipboard.writeText(server.invite_code)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
    setShowMenu(false)
  }

  const leaveServer = async () => {
    await supabase.from('server_members')
      .delete()
      .eq('server_id', server.id)
      .eq('user_id', profile.id)
    onServerUpdate()
    navigate('/')
    setShowMenu(false)
  }

  const deleteServer = async () => {
    if (!window.confirm(`Delete "${server.name}"? This cannot be undone.`)) return
    await supabase.from('servers').delete().eq('id', server.id)
    onServerUpdate()
    navigate('/')
    setShowMenu(false)
  }

  const textChannels  = channels.filter(c => c.type === 'text')
  const voiceChannels = channels.filter(c => c.type === 'voice')

  return (
    <div className="flex flex-col flex-1 overflow-hidden">
      {/* Server header */}
      <div className="relative flex-shrink-0">
        <button
          onClick={() => setShowMenu(!showMenu)}
          className="w-full flex items-center justify-between px-4 py-3 hover:bg-raptor-raised transition-colors border-b border-raptor-border"
        >
          <span className="font-semibold text-raptor-text truncate">{server.name}</span>
          <ChevronDown size={16} className={`text-raptor-sub flex-shrink-0 transition-transform ${showMenu ? 'rotate-180' : ''}`} />
        </button>

        {/* Server dropdown menu */}
        {showMenu && (
          <div className="absolute top-full left-2 right-2 mt-1 bg-raptor-surface border border-raptor-border rounded-lg shadow-2xl overflow-hidden z-50 animate-slide-up">
            <MenuItem icon={<Copy size={14} />} onClick={copyInvite}>
              {copied ? 'Copied!' : 'Copy Invite Code'}
            </MenuItem>
            {isOwner && (
              <MenuItem icon={<Settings size={14} />} onClick={() => { setShowSettings(true); setShowMenu(false) }}>
                Server Settings
              </MenuItem>
            )}
            <div className="h-px bg-raptor-border mx-2 my-1" />
            <MenuItem icon={<LogOut size={14} />} onClick={leaveServer} danger>
              Leave Server
            </MenuItem>
            {isOwner && (
              <MenuItem icon={<Trash2 size={14} />} onClick={deleteServer} danger>
                Delete Server
              </MenuItem>
            )}
          </div>
        )}
      </div>

      {/* Channel list */}
      <div className="flex-1 overflow-y-auto py-2 px-2 space-y-4">
        {/* Text channels */}
        <ChannelSection
          label="Text Channels"
          onAdd={isOwner ? () => setShowCreateCh({ type: 'text' }) : null}
        >
          {textChannels.map(ch => (
            <ChannelRow
              key={ch.id}
              channel={ch}
              active={ch.id === channelId}
              onClick={() => navigate(`/channels/${server.id}/${ch.id}`)}
            />
          ))}
        </ChannelSection>

        {/* Voice channels */}
        <ChannelSection
          label="Voice Channels"
          onAdd={isOwner ? () => setShowCreateCh({ type: 'voice' }) : null}
        >
          {voiceChannels.map(ch => (
            <ChannelRow
              key={ch.id}
              channel={ch}
              active={ch.id === channelId}
              onClick={() => navigate(`/channels/${server.id}/${ch.id}`)}
            />
          ))}
        </ChannelSection>

        {/* Members list */}
        {members.length > 0 && (
          <div>
            <p className="text-raptor-faint text-xs font-semibold uppercase tracking-wider px-2 mb-1">
              Members — {members.length}
            </p>
            <div className="space-y-0.5">
              {members.map(m => m.users && (
                <div key={m.user_id} className="flex items-center gap-2 px-2 py-1 rounded hover:bg-raptor-raised transition-colors">
                  <div className="relative">
                    <div className="w-6 h-6 rounded-full bg-raptor-muted flex items-center justify-center text-xs font-bold text-raptor-text flex-shrink-0">
                      {m.users.username?.[0]?.toUpperCase()}
                    </div>
                    <span className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border border-raptor-dark ${
                      { online: 'bg-raptor-online', idle: 'bg-raptor-idle', dnd: 'bg-raptor-dnd', invisible: 'bg-raptor-ghost' }[m.users.status] ?? 'bg-raptor-ghost'
                    }`} />
                  </div>
                  <span className="text-raptor-sub text-xs truncate">{m.users.username}</span>
                  {m.role === 'owner' && (
                    <span className="ml-auto text-raptor-amber text-xs">★</span>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {showCreateCh && (
        <CreateChannelModal
          server={server}
          defaultType={showCreateCh.type}
          onClose={() => setShowCreateCh(false)}
          onCreated={(ch) => { fetchChannels(); setShowCreateCh(false); navigate(`/channels/${server.id}/${ch.id}`) }}
        />
      )}
      {showSettings && (
        <ServerSettingsModal
          server={server}
          onClose={() => setShowSettings(false)}
          onUpdated={onServerUpdate}
        />
      )}
    </div>
  )
}

function ChannelSection({ label, children, onAdd }) {
  return (
    <div>
      <div className="flex items-center justify-between px-2 mb-0.5">
        <p className="text-raptor-faint text-xs font-semibold uppercase tracking-wider">{label}</p>
        {onAdd && (
          <button onClick={onAdd} className="text-raptor-faint hover:text-raptor-text transition-colors">
            <Plus size={14} />
          </button>
        )}
      </div>
      <div className="space-y-0.5">{children}</div>
    </div>
  )
}

function ChannelRow({ channel, active, onClick }) {
  const Icon = channel.type === 'voice' ? Volume2 : Hash
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-1.5 px-2 py-1.5 rounded-md text-sm transition-colors text-left group ${
        active
          ? 'active-channel-bar bg-raptor-raised text-raptor-text'
          : 'text-raptor-faint hover:bg-raptor-raised hover:text-raptor-sub'
      }`}
    >
      <Icon size={15} className="flex-shrink-0" />
      <span className="truncate">{channel.name}</span>
    </button>
  )
}

function MenuItem({ icon, children, onClick, danger = false }) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-2.5 px-3 py-2 text-sm transition-colors mx-1 rounded my-0.5 ${
        danger
          ? 'text-raptor-dnd hover:bg-raptor-dnd/10'
          : 'text-raptor-text hover:bg-raptor-raised'
      }`}
    >
      {icon}
      {children}
    </button>
  )
}
